﻿
namespace exc.jdbi.PasswordCheckers;
public enum PasswordStrength
{
  Unacceptable,
  Weak,
  Ok,
  Strong,
  Secure
}
