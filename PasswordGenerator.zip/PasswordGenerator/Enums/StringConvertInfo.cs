﻿

namespace exc.jdbi.Converts;
public enum StringConvertInfo
{
  None,
  Hex,
  Base32,
  Base62,
  Base64
}
